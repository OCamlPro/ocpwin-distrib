(* This is demo input for wiki. It wil be loaded automatically into window on startup *)

let test1 = "

====this is h4

# number list  el 1
# number list e2 2 //with italic text


//with italic

* bullet list el1 ** with bold text
* bullet list el2 ** with bold // and italic text

<<youtube 1XNTjVScm_8>>

[[http://ya.ru|Link to Yandex]]

[[http://google.com]]

{{http://icons-search.com/img/yellowicon/firefox_win.zip/Firefox_Thunderbird_Win-icons-Firefox.ico-128x128.png|mail icon}}

{{{
== [[Nowiki]]:
//**don't** format//
}}}


"
