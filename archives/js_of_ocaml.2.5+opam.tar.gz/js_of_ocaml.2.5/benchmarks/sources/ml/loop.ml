for i = 1 to 1000000000 do () done
