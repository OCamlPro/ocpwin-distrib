* Support for bash autocompletion.
